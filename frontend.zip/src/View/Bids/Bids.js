import React from 'react'

function Bids() {
  return (
    <div>Bids</div>
  )
}

export default Bids