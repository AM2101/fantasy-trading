

import React, { useState, useRef } from 'react';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';
import indicatorsAll from 'highcharts/indicators/indicators-all';
import annotationsAdvanced from "highcharts/modules/annotations-advanced";
import stockTools from "highcharts/modules/stock-tools";
import "./Graph.css";
import HighchartsFullscreen from 'highcharts/modules/full-screen';
// import load from '../../assets/Images/giphy.gif'

HighchartsFullscreen(Highcharts);

indicatorsAll(Highcharts);
annotationsAdvanced(Highcharts);
stockTools(Highcharts);

const datalist = await fetch(
  'http://localhost:8081/stockdata'
).then(response => response.json());

const Graph = () => {
    // console.log(datalist);
  const chartComponentRef = useRef(null);
//   const [loading, setLoading] = useState(true);
  const [options] = useState({

    

    exporting: {
      allowHTML: true,
      buttons: {
        contextButton: {
          menuItems: [{
            text: 'Change Type',
            onclick: function() {
              var chart = this;
              var types = ['line', 'column', 'ohlc', 'candlestick']; // Add other types if needed
              var currentType = chart.series[0].type;
              var nextType = types[(types.indexOf(currentType) + 1) % types.length];
              chart.series[0].update({ type: nextType });
            }
          }, {
            text: 'Full Screen',
            onclick: function() {
              this.fullscreen.toggle();
            }
          }]
        }
      },
      enabled: true
    },
    navigator : {
      enabled : false,
      
      },
    //   srcollbar: {
    //     enabled: false
    // },

    navigation: {
        buttonOptions: {
          align: 'left',
          verticalAlign: 'top',
          y: 0
        }
      },
      stockTools: {
        gui: {
            
          enabled: true,
        //   buttons: ['simpleShapes', 'lines', 'crookedLines', 'measure', 'advanced', 'toggleAnnotations', 'separator', 'fullScreen']
          buttons: ['separator','separator','typeChange','separator', 'fullScreen'],
          fullScreen: {
            /**
             * A predefined background symbol for the button.
             *
             * @type   {string}
             */
            symbol: 'fullscreen.svg'
        },
          definitions:{
            typeChange: {
                
                items: [
                    'typeOHLC',
                    'typeLine',
                    'typeCandlestick',
                    // 'typeHollowCandlestick',
                    'typeHLC',
                    // 'typeHeikinAshi'
                ],
            }
        }
        },
        
      },


    chart: {
    //   height: (9 / 16 * 100) + '%',
    height:"590px",
      renderTo: 'container',
    },
    rangeSelector: {
      selected: 0,
      inputEnabled: false,
      buttons: [
        {
          type: 'min',
          count: 1,
          text: '1m',
          events: {
            click: () => {
              const chart = chartComponentRef.current.chart;
              if (chart) {
                const lastPoint = chart.xAxis[0].dataMax;
                const newMin = lastPoint - (1 * 60 * 1000);

                chart.update({
                  xAxis: {
                    min: newMin,
                    max: lastPoint
                  }
                });
              }
            }
          }
        },
        {
          type: 'min',
          count: 5,
          text: '5m',
          events: {
            click: () => {
              const chart = chartComponentRef.current.chart;
              if (chart) {
                const lastPoint = chart.xAxis[0].dataMax;
                const newMin = lastPoint - (5 * 60 * 1000);

                chart.update({
                  xAxis: {
                    min: newMin,
                    max: lastPoint
                  }
                });
              }
            }
          }
        },
        {
          type: 'hour',
          count: 1,
          text: '1H',
          dataGrouping: {
            forced: true,
            units: [
              [
                'minute',
                [1, 2, 5, 10, 15, 30]
              ],
              ['hour', [1]],
              [
                'day',
                [1]
              ]
            ]
          }
        },
        {
          type: 'day',
          count: 3,
          text: '1D',
          dataGrouping: {
            // forced: true,
            // units: [['day', [1]]]
          }
        },
        {
          type: 'month',
          count: 1,
          text: '1mo',
          events: {
            click: function () {
            //   alert('Clicked button');
            }
          }
        },
        {
          type: 'month',
          count: 6,
          text: '6mo'
        },
        {
          type: 'year',
          count: 1,
          text: '1y'
        },
        {
          type: 'all',
          text: 'All'
        }
      ]
    },

    


    yAxis: [
      {
        labels: {
          align: "left"
        },
        height: "100%",
        resize: {
          enabled: false
        }
      },
      {
        labels: {
          align: "left"
        },
        top: "80%",
        height: "30%",
        offset: 0
      }
    ],
    xAxis: {
      type: 'datetime',
      tickInterval: 120000,
      dateTimeLabelFormats: {
        second: '%H:%M:%S',
        minute: '%H:%M',
        hour: '%H:%M',
        day: '%e. %b',
        week: '%e. %b',
        month: '%b \'%y',
        year: '%Y'
      },
      events: {}
    },
    title: {
      text: "Summary"
    },
    tooltip: {
      formatter: function () {
        return [''].concat(
          this.points ?
            this.points.map(function (point) {
              console.log(point);
              return point.series.name + `: O<span style=color:${point.color}>` + parseFloat(point.point.plotOpen).toFixed(2) + `</span> H<span style="color:${point.color}">` + parseFloat(point.point.plotHigh).toFixed(2) + `</span> L<span style="color:${point.color}">` + parseFloat(point.point.plotLow).toFixed(2) + `</span> C<span style="color:${point.color}">` + parseFloat(point.point.plotClose).toFixed(2) + '</span>';
            }) : []
        );
      },
      useHTML: true,
      borderWidth: 0,
      shadow: false,
      positioner: function (width, height, point) {
        const chart = this.chart;
        let position;
        if (point.isHeader) {
          position = {
            x: Math.max(
              chart.plotLeft,
              Math.min(
                point.plotX + chart.plotLeft - width / 2,
                chart.chartWidth - width - chart.marginRight
              )
            ),
            y: point.plotY
          };
        } else {
          position = {
            x: point.series.chart.plotLeft,
            y: point.series.yAxis.top - chart.plotTop
          };
        }

        return position;
      }
    },
    series: [
      {
        id: 'actorchart-series',
        type: 'candlestick',
        color: '#f23645',
        upColor: '#089981',
        upLineColor: '#089981',
        lineColor: '#f23645',
        name: "INFY",
        showInNavigator: true,
        data: datalist
      }
    ]
  });

//   const handleChartTypeChange = (e) => {
//     const chartType = e.target.value;
//     const chart = chartComponentRef.current.chart;
//     if (chart) {
//       chart.update({
//         series: [{
//           ...options.series[0],
//           type: chartType
//         }]
//       });
//     }
//   };

  return (
    <>
      <link rel="stylesheet" type="text/css" href="https://code.highcharts.com/css/stocktools/gui.css"/>
      <link rel="stylesheet" type="text/css" href="https://code.highcharts.com/css/annotations/popup.css"/>
      {/* <script src="https://code.highcharts.com/stock/highstock.js"></script>
      <script src="https://code.highcharts.com/stock/modules/drag-panes.js"></script>
      <script src="https://code.highcharts.com/stock/indicators/bollinger-bands.js"></script>
      <script src="https://code.highcharts.com/stock/indicators/ema.js"></script>
      <script src="https://code.highcharts.com/stock/modules/annotations-advanced.js"></script>
      <script src="https://code.highcharts.com/stock/modules/full-screen.js"></script>
      <script src="https://code.highcharts.com/stock/modules/stock-tools.js"></script> */}
      {/* <select className="chartchange-select" onChange={handleChartTypeChange}>
        <option value="candlestick">Candlestick</option>
        <option value="line">Line</option>
        
      </select> */}

      
      <div id='container'>
     
      <HighchartsReact
        ref={chartComponentRef}
        highcharts={Highcharts}
        constructorType={"stockChart"}
        options={options}
        allowChartUpdate
      />
      </div>
      
    </>
  );
};

export default Graph;

