import React from 'react'

function Positions() {
  return (
    <div>Positions</div>
  )
}

export default Positions