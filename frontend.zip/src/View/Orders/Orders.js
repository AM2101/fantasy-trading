import React from 'react'
// import List from '../../Components/List/List'

function Orders() {
  return (
            <div>Orders</div>
  )
}

export default Orders