import React from 'react'

function Funds() {
  return (
    <div>Funds</div>
  )
}

export default Funds