import React from 'react'

function Holding() {
  return (
    <div>Holding</div>
  )
}

export default Holding