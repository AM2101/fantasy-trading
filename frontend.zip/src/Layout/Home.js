import React from 'react'
import { Footer, Header } from '../Components'

function Home() {
  return (
    <div>
        <Header/>
        <Footer/>
    </div>
  )
}

export default Home